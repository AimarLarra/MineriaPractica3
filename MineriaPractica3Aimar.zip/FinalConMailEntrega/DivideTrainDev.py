import os.path

from sklearn.model_selection import train_test_split
import csv
from FlagEmbedding import FlagModel
import numpy as np
from nltk.tokenize import word_tokenize
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords
import nltk
from nltk.corpus import stopwords
import re
from sentence_transformers import SentenceTransformer


def read_csv_and_generate_arrays(csv_file):

    # Inicializar los modelos
    model = FlagModel('BAAI/bge-base-en',
                      query_instruction_for_retrieval="Represent this sentence for searching relevant passages: ",
                      use_fp16=True)
    model2 = SentenceTransformer("flax-sentence-embeddings/st-codesearch-distilroberta-base")

    # Obtener datos y clases
    with open(csv_file, 'r', newline='') as csvfile:
        datos = []
        clases = []

        next(csvfile, None)
        reader = csv.reader(csvfile)
        # Iterate through rows and rename second column
        for row in reader:
            if len(row) >= 2:
                datos.append(row[0].strip())
                clases.append(row[1].strip())
    csvfile.close()

    #Realizar pre-procesamiento de datos (filtrado tokenizado y stop-words eliminadas)
    cachedStopWords = set(stopwords.words("english"))
    for i in range(0, len(datos)):
        # Filtrar caracteres que no siguen la codificación
        text = re.sub(r'[^\x00-\x7F]+', ' ', datos[i])
        text = text.replace(".", "")
        # Eliminar comillas simples al principio y al final
        text = text.strip("'")
        # Tokenización
        words = word_tokenize(text)
        # Pasar a minúsculas y eliminar stopwords
        words = [word.lower() for word in words if word.lower() not in cachedStopWords]
        # Filtrar palabras de longitud mínima
        words = [word for word in words if len(word) >= 3]
        datos[i] = ' '.join(words)

    # Dividir entre muestra de entrenamiento y desarrollo
    X_train, X_test, y_train, y_test = train_test_split(datos, clases, test_size=0.3, random_state=109)

    # Crear diccionario con ({Clase}, [array de autopsias]
    trainDict = {}
    print("\nTrainDict")
    for i in range(0, len(y_train)):
        key = y_train[i]
        value = X_train[i]
        if key in trainDict:
            trainDict[key].append(value)
        else:
            trainDict[key] = [value]

    # Comprobar si existe el último archivo de embeddings que guardamos y si no existe
    # los creamos y guardamos
    if not os.path.exists("Embeddings\\ECMM2.npy"):
        for key, values in trainDict.items():
            if key == "Endocrine, Nutritional and Metabolic Diseases":
                ENMB_emb = model.encode(values)
                ENMB_emb2 = model2.encode(values)
            elif key == "Neoplasms":
                NPS_emb = model.encode(values)
                NPS_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Certain infectious and Parasitic Diseases":
                CIPD_emb = model.encode(values)
                CIPD_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Diseases of the Nervous System":
                DNS_emb = model.encode(values)
                DNS_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Diseases of the circulatory system":
                DCS_emb = model.encode(values)
                DCS_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Diseases of Respiratory System":
                DRS_emb = model.encode(values)
                DRS_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Diseases of the Digestive System":
                DDS_emb = model.encode(values)
                DDS_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Diseases of the Genitourinary System":
                DGS_emb = model.encode(values)
                DGS_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Pregnancy, childbirth and the puerperium":
                PCP_emb = model.encode(values)
                PCP_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Congenital Malformations":
                CM_emb = model.encode(values)
                CM_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Injury, Poisoning and External Causes":
                IPEC_emb = model.encode(values)
                IPEC_emb2 = model2.encode(values, convert_to_tensor=True)
            if key == "External Causes of Morbidity and Mortality":
                ECMM_emb = model.encode(values)
                ECMM_emb2 = model2.encode(values, convert_to_tensor=True)
            elif key == "Congenital Malformations":
                CM_emb = model.encode(values)
                CM_emb2 = model2.encode(values, convert_to_tensor=True)

    # Guardamos los embeddings en la carpeta Embeddings,
    # plano para FlagEmbeddings, 2 para SentenceEmbeddings
        ENMB_emb = np.array(ENMB_emb)
        np.save('Embeddings\\ENMB.npy', ENMB_emb)
        ENMB_emb2 = np.array(ENMB_emb2)
        np.save('Embeddings\\ENMB2.npy', ENMB_emb2)
        NPS_emb = np.array(NPS_emb)
        np.save('Embeddings\\NPS.npy', NPS_emb)
        NPS_emb2 = np.array(NPS_emb2)
        np.save('Embeddings\\NPS2.npy', NPS_emb2)
        CIPD_emb = np.array(CIPD_emb)
        np.save('Embeddings\\CIPD.npy', CIPD_emb)
        CIPD_emb2 = np.array(CIPD_emb2)
        np.save('Embeddings\\CIPD2.npy', CIPD_emb2)
        DNS_emb = np.array(DNS_emb)
        np.save('Embeddings\\DNS.npy', DNS_emb)
        DNS_emb2 = np.array(DNS_emb2)
        np.save('Embeddings\\DNS2.npy', DNS_emb2)
        DCS_emb = np.array(DCS_emb)
        np.save('Embeddings\\DCS.npy', DCS_emb)
        DCS_emb2 = np.array(DCS_emb2)
        np.save('Embeddings\\DCS2.npy', DCS_emb2)
        DRS_emb = np.array(DRS_emb)
        np.save('Embeddings\\DRS.npy', DRS_emb)
        DRS_emb2 = np.array(DRS_emb2)
        np.save('Embeddings\\DRS2.npy', DRS_emb2)
        DDS_emb = np.array(DDS_emb)
        np.save('Embeddings\\DDS.npy', DDS_emb)
        DDS_emb2 = np.array(DDS_emb2)
        np.save('Embeddings\\DDS2.npy', DDS_emb2)
        DGS_emb = np.array(DGS_emb)
        np.save('Embeddings\\DGS.npy', DGS_emb)
        DGS_emb2 = np.array(DGS_emb2)
        np.save('Embeddings\\DGS2.npy', DGS_emb2)
        PCP_emb = np.array(PCP_emb)
        np.save('Embeddings\\PCP.npy', PCP_emb)
        PCP_emb2 = np.array(PCP_emb2)
        np.save('Embeddings\\PCP2.npy', PCP_emb2)
        CM_emb = np.array(CM_emb)
        np.save('Embeddings\\CM.npy', CM_emb)
        CM_emb2 = np.array(CM_emb2)
        np.save('Embeddings\\CM2.npy', CM_emb2)
        IPEC_emb = np.array(IPEC_emb)
        np.save('Embeddings\\IPEC.npy', IPEC_emb)
        IPEC_emb2 = np.array(IPEC_emb2)
        np.save('Embeddings\\IPEC2.npy', IPEC_emb2)
        ECMM_emb = np.array(ECMM_emb)
        np.save('Embeddings\\ECMM.npy', ECMM_emb)
        ECMM_emb2 = np.array(ECMM_emb2)
        np.save('Embeddings\\ECMM2.npy', ECMM_emb2)

    # Cargamos los embeddings a variables
    for key in trainDict.keys():

        if key == "Endocrine, Nutritional and Metabolic Diseases":
            ENMB_emb = np.load("Embeddings\\ENMB.npy")
            ENMB_emb2 = np.load("Embeddings\\ENMB2.npy")

        elif key == "Neoplasms":
            NPS_emb = np.load("Embeddings\\NPS.npy")
            NPS_emb2 = np.load("Embeddings\\NPS2.npy")

        elif key == "Certain infectious and Parasitic Diseases":
            CIPD_emb = np.load("Embeddings\\CIPD.npy")
            CIPD_emb2 = np.load("Embeddings\\CIPD2.npy")

        elif key == "Diseases of the Nervous System":
            DNS_emb = np.load("Embeddings\\DNS.npy")
            DNS_emb2 = np.load("Embeddings\\DNS2.npy")

        elif key == "Diseases of the circulatory system":
            DCS_emb = np.load("Embeddings\\DCS.npy")
            DCS_emb2 = np.load("Embeddings\\DCS2.npy")

        elif key == "Diseases of Respiratory System":
            DRS_emb = np.load("Embeddings\\DRS.npy")
            DRS_emb2 = np.load("Embeddings\\DRS2.npy")

        elif key == "Diseases of the Digestive System":
            DDS_emb = np.load("Embeddings\\DDS.npy")
            DDS_emb2 = np.load("Embeddings\\DDS2.npy")

        elif key == "Diseases of the Genitourinary System":
            DGS_emb = np.load("Embeddings\\DGS.npy")
            DGS_emb2 = np.load("Embeddings\\DGS2.npy")

        elif key == "Pregnancy, childbirth and the puerperium":
            PCP_emb = np.load("Embeddings\\PCP.npy")
            PCP_emb2 = np.load("Embeddings\\PCP2.npy")

        elif key == "Congenital Malformations":
            CM_emb = np.load("Embeddings\\CM2.npy")
            CM_emb2 = np.load("Embeddings\\CM2.npy")

        elif key == "Injury, Poisoning and External Causes":
            IPEC_emb = np.load("Embeddings\\IPEC.npy")
            IPEC_emb2 = np.load("Embeddings\\IPEC2.npy")

        elif key == "External Causes of Morbidity and Mortality":
            ECMM_emb = np.load("Embeddings\\ECMM.npy")
            ECMM_emb2 = np.load("Embeddings\\ECMM2.npy")

    

    # Realizamos las predicciones para cada modelo
    with open("Datos\\predicciones.txt", "w") as file:
        for i in range(0, len(X_test)):
            maxSimilarity1 = -99999
            maxSimilarity2 = -99999
            maxSimilarity3 = -99999
            maxSimilarity4 = -99999

            fraseEvaluar = X_test[i]
            fraseEvaluarEmbedded = model.encode(fraseEvaluar)
            fraseEvaluarEmbedded2 = model2.encode(fraseEvaluar, convert_to_tensor=False)
            claseCorrecta = y_test[i]
            for clase in trainDict.keys():
                if clase == "Endocrine, Nutritional and Metabolic Diseases":
                    frasesClaseEmbedded = ENMB_emb
                    frasesClaseEmbedded2 = ENMB_emb2
                elif clase == "Neoplasms":
                    frasesClaseEmbedded = NPS_emb
                    frasesClaseEmbedded2 = NPS_emb2
                elif clase == "Certain infectious and Parasitic Diseases":
                    frasesClaseEmbedded = CIPD_emb
                    frasesClaseEmbedded2 = CIPD_emb2
                elif clase == "Diseases of the Nervous System":
                    frasesClaseEmbedded = DNS_emb
                    frasesClaseEmbedded2 = DNS_emb2
                elif clase == "Diseases of the circulatory system":
                    frasesClaseEmbedded = DCS_emb
                    frasesClaseEmbedded2 = DCS_emb2
                elif clase == "Diseases of Respiratory System":
                    frasesClaseEmbedded = DRS_emb
                    frasesClaseEmbedded2 = DRS_emb2
                elif clase == "Diseases of the Digestive System":
                    frasesClaseEmbedded = DDS_emb
                    frasesClaseEmbedded2 = DDS_emb2
                elif clase == "Diseases of the Genitourinary System":
                    frasesClaseEmbedded = DGS_emb
                    frasesClaseEmbedded2 = DGS_emb2
                elif clase == "Pregnancy, childbirth and the puerperium":
                    frasesClaseEmbedded = PCP_emb
                    frasesClaseEmbedded2 = PCP_emb2
                elif clase == "Congenital Malformations":
                    frasesClaseEmbedded = CM_emb
                    frasesClaseEmbedded2 = CM_emb2
                elif clase == "Injury, Poisoning and External Causes":
                    frasesClaseEmbedded = IPEC_emb
                    frasesClaseEmbedded2 = IPEC_emb2
                elif clase == "External Causes of Morbidity and Mortality":
                    frasesClaseEmbedded = ECMM_emb
                    frasesClaseEmbedded2 = ECMM_emb2

                similarity1 = fraseEvaluarEmbedded @ frasesClaseEmbedded.T
                similarityMean1 = np.mean(similarity1)
                similarity2 = fraseEvaluarEmbedded @ frasesClaseEmbedded2.T
                similarityMean2 = np.mean(similarity2)
                similarity3 = fraseEvaluarEmbedded2 @ frasesClaseEmbedded.T
                similarityMean3 = np.mean(similarity3)
                similarity4 = fraseEvaluarEmbedded2 @ frasesClaseEmbedded2.T
                similarityMean4 = np.mean(similarity4)
                print("Similarity: " + str(similarityMean1) + " clase: " + str(clase))
                if similarityMean1 > maxSimilarity1:
                    maxSimilarity1 = similarityMean1
                    clasePredicha1 = clase
                if similarityMean2 > maxSimilarity2:
                    maxSimilarity2 = similarityMean2
                    clasePredicha2 = clase
                if similarityMean3 > maxSimilarity3:
                    maxSimilarity3 = similarityMean3
                    clasePredicha3 = clase
                if similarityMean4 > maxSimilarity4:
                    maxSimilarity4 = similarityMean4
                    clasePredicha4 = clase
            print("Clase predicha es: " + clasePredicha1 + "-->" + claseCorrecta)
            file.write("Iter:" + str(i) + "; Pred:" + str(clasePredicha1) + "; Pred2:" + str(clasePredicha2) + "; Pred3:" + str(clasePredicha3) + "; Pred4:" + str(clasePredicha4) + "; Real:" + str(claseCorrecta) + "\n")
    file.close()


read_csv_and_generate_arrays("Datos\\filteredtraindev.csv")
