from sklearn.model_selection import train_test_split
import Datos as dt
import csv

def rename_second_column(input_csv, output_csv):
    # Define your mapping here
    mapping = {
        'diarrhea/dysentery': 'Certain infectious and Parasitic Diseases',
        'other infectious diseases': 'Certain infectious and Parasitic Diseases',
        'aids': 'Certain infectious and Parasitic Diseases',
        'sepsis': 'Certain infectious and Parasitic Diseases',
        'meningitis': 'Certain infectious and Parasitic Diseases',
        'meningitis/sepsis': 'Certain infectious and Parasitic Diseases',
        'malaria': 'Certain infectious and Parasitic Diseases',
        'encephalitis': 'Certain infectious and Parasitic Diseases',
        'measles': 'Certain infectious and Parasitic Diseases',
        'hemorrhagic fever': 'Certain infectious and Parasitic Diseases',
        'tb': 'Certain infectious and Parasitic Diseases',
        'leukemia/lymphomas': 'Neoplasms',
        'colorectal cancer': 'Neoplasms',
        'lung cancer': 'Neoplasms',
        'cervical cancer': 'Neoplasms',
        'breast cancer': 'Neoplasms',
        'stomach cancer': 'Neoplasms',
        'prostate cancer': 'Neoplasms',
        'esophageal cancer': 'Neoplasms',
        'other cancers': 'Neoplasms',
        'diabetes': 'Endocrine, Nutritional and Metabolic Diseases',
        'epilepsy': 'Diseases of the Nervous System',
        'stroke': 'Diseases of the circulatory system',
        'acute myocardial infarction': 'Diseases of the circulatory system',
        'other cardiovascular diseases': 'Diseases of the circulatory system',
        'pneumonia': 'Diseases of Respiratory System',
        'asthma': 'Diseases of Respiratory System',
        'copd': 'Diseases of Respiratory System',
        'cirrhosis': 'Diseases of the Digestive System',
        'other digestive diseases': 'Diseases of the Digestive System',
        'renal failure': 'Diseases of the Genitourinary System',
        'preterm delivery': 'Pregnancy, childbirth and the puerperium',
        'stillbirth': 'Pregnancy, childbirth and the puerperium',
        'maternal': 'Pregnancy, childbirth and the puerperium',
        'birth asphyxia': 'Pregnancy, childbirth and the puerperium',
        'other defined causes of child deaths': 'Pregnancy, childbirth and the puerperium',
        'congenital malformation': 'Congenital Malformations',
        'bite of venomous animal': 'Injury, Poisoning and External Causes',
        'poisonings': 'Injury, Poisoning and External Causes',
        'road traffic': 'External Causes of Morbidity and Mortality',
        'falls': 'External Causes of Morbidity and Mortality',
        'homicide': 'External Causes of Morbidity and Mortality',
        'fires': 'External Causes of Morbidity and Mortality',
        'drowning': 'External Causes of Morbidity and Mortality',
        'suicide': 'External Causes of Morbidity and Mortality',
        'violent death': 'External Causes of Morbidity and Mortality',
        'other injuries': 'External Causes of Morbidity and Mortality',
        'other non-communicable diseases': 'External Causes of Morbidity and Mortality'
        # Add more mappings as needed
    }

    with open(input_csv, 'r', newline='') as infile, open(output_csv, 'w', newline='') as outfile:
        reader = csv.reader(infile)
        writer = csv.writer(outfile)

        # Write header
        header = next(reader)
        writer.writerow(header)

        # Iterate through rows and rename second column
        for row in reader:
            if len(row) >= 2:
                old_value = row[1].lower().strip()
                new_value = mapping.get(old_value.lower(), old_value.lower())
                row[1] = new_value
            writer.writerow(row)

# Example usage:
input_csv_file = 'Datos\\traindev.csv'  # Replace with the path to your input CSV file
output_csv_file = 'Datos\\filteredtraindev.csv'  # Replace with the desired output CSV file

rename_second_column(input_csv_file, output_csv_file)



# Split dataset into training set and test set
# X_train, X_test, y_train, y_test = train_test_split(cancer.data, cancer.target, test_size=0.3,random_state=109)