import matplotlib.pyplot as plt

pred1count = 0
acuracy1 = 0
pred2count = 0
acuracy2 = 0
pred3count = 0
acuracy3 = 0
pred4count = 0
acuracy4 = 0
linecount = 0
with open("Datos\\predicciones.txt", 'r') as file:
    for line in file:
        parts = line.strip().split(';')
        pred1 = parts[1].strip().split(':')[1]
        pred2 = parts[2].strip().split(':')[1]
        pred3 = parts[3].strip().split(':')[1]
        pred4 = parts[4].strip().split(':')[1]
        real = parts[5].strip().split(':')[1]
        if pred1 == real:
            pred1count = pred1count + 1
        if pred2 == real:
            pred2count = pred2count + 1
        if pred3 == real:
            pred3count = pred3count + 1
        if pred4 == real:
            pred4count = pred4count + 1
        linecount = linecount + 1
    acuracy1 = pred1count/linecount
    acuracy2 = pred2count/linecount
    acuracy3 = pred3count / linecount
    acuracy4 = pred4count / linecount
file.close()

with open("Datos\\metrics.txt", 'w') as file2:
    file2.write("Acuraccy 1st model:" + str(acuracy1) + "Acuraccy 2nd model:" + str(acuracy2) + "Acuraccy 3rd model:" + str(acuracy3) + "Acuraccy 4th model:" + str(acuracy4) + "\n")
file2.close()

# Assuming you have four accuracy values
accuracies = [acuracy1, acuracy2, acuracy3, acuracy4]

# Names for each bar (you can replace these with meaningful labels)
class_names = ['Model 1', 'Model 2', 'Model 3', 'Model 4']

# Plotting the bar graph
plt.bar(class_names, accuracies, color='blue')

# Adding labels and title
plt.xlabel('Models')
plt.ylabel('Accuracy')
plt.title('Accuracy for Each Model')

# Display the plot
plt.show()
