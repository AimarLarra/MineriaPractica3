import csv

def delete_csv_column(input_file, output_file):
    with open(input_file, 'r') as infile, open(output_file, 'w', newline='') as outfile:
        reader = csv.reader(infile)
        writer = csv.writer(outfile)

        for row in reader:
            for i in reversed(range(0,5)):
                print(i)
                # Remove the column at the specified index
                del row[i]
            writer.writerow(row)

# Example usage:
input_file = 'Datos\\cleaned_PHMRC_VAI_redacted_free_text.train.csv'
output_file = 'Datos\\traindev.csv'


delete_csv_column(input_file, output_file)
