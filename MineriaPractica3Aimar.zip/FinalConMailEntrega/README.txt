Versión de python utilizada: 3.9

-Requisitos para una ejecución correcta:

    -Datos filtrados (filteredtraindev.csv) Los podemos conseguir mediante Rellabeling y DeleteColumnCSV
    -Ambos modelos bge-reranker-large y st-codesearch-distilroberta-base descargados de HuggingFace con el mismo nombre

-Archivos que se crean:

	-predicciones.txt: Se muestra las predicciones que han hecho nuestros 4 modelos para cada instancia, y tambien la clase real
	-metrics.txt: Se calculan aquí las precisiones de nuestros 4 modelos
	-myplot.png: gráfico de barras que enseña las precisiones comparadas de nuestros modelos
	